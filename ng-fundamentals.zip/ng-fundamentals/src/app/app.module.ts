import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router'
import { EventsAppComponent } from './events-app.component';
import { NavbarComponent } from './nav/navbar.component';
import { appRoutes } from './routes';
import { ErrorComponent } from './errors/error.component'
import { 
  CreateEventComponent,
  EventDetailsComponent,
  EventRouteActivatorService,
  EventsListComponent,
  EventsListResolverService,
  EventsService,
  EventThumbnailComponent

} from './events/index';

@NgModule({
  declarations: [
    EventsAppComponent,
    EventsListComponent,
    EventThumbnailComponent,
    NavbarComponent,
    EventDetailsComponent,
    CreateEventComponent,
    ErrorComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [
    {provide: 'canDeactivateCreateEvent', useValue: checkDirtyState}
  ],
  bootstrap: [EventsAppComponent]
})
export class AppModule { 

}
export function checkDirtyState(component:CreateEventComponent){
    if(component.isDirty){
      return window.confirm('You have not saved the changes. Do you still want to continue?')
    }
    else
    {return true};
  }
