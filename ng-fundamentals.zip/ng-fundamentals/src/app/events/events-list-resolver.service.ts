import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { map } from 'rxjs/operators';
import { EventsService } from './shared/events.service'

@Injectable({
  providedIn: 'root'
})
export class EventsListResolverService implements Resolve<any> {

  constructor(private eventService: EventsService) { }

  resolve(){
    return this.eventService.getEvents().pipe(map(events=>events));
  }
}
