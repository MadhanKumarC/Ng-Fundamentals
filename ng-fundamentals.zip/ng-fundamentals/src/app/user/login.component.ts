import { Component, OnInit } from '@angular/core';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';

@Component({
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit {

  userName:string 
  passWord:string
  constructor(private auth: AuthService, private router: Router) { }

  submitForm(formValues){
    this.auth.loginUser(formValues.userName, formValues.passWord);
    this.router.navigate(['events']);
  }

  ngOnInit() {
  }

}
